-----------------------------------------------------------------
The collected data has not changed for this submission.

Analyze script runs indefinitely giving suggestion every 30 seconds unless triggered to stop.

Log file contains the output that was obtained by running 40, 80, 120 threads consecutively for every 3 minutes.
-----------------------------------------------------------------